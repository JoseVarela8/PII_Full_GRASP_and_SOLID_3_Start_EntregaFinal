//Interface
namespace Full_GRASP_And_SOLID.Library
{
    public interface Iimprimir
        {void Imprimir(Recipe recipe);}
}