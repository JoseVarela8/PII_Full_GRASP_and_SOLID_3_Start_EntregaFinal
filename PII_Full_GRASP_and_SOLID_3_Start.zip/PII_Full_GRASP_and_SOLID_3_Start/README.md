# PII Full GRASP and SOLID
## FIT
### Universidad Católica del Uruguay

En este programa trabajaremos con recetas de cocina que involucran ingredientes y equipamiento.

## Desafío(s)

️➡️ **Modifiquen el código provisto para evitar preguntar por el destino de la impresión en la clase AllInOnePrinter para imprimir en diferentes destinos -impresora o consola-.**

➡️ **¿Qué patrón o principio usan para asignar esta responsabilidad? Escriban la respuesta en comentarios en el código.**